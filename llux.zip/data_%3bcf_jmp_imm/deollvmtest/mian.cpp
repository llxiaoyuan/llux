#include<Windows.h>
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>

int g_v = 0;
// return n
int sum(int n) {
    if (n == 0) {
        return 0;
    }
    return 1 + sum(n - 1);
}
int __stdcall stack_test(int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    int result = 0;
    for (size_t i = 0; i < sum(2); i++) {
        if (i == 0) {
            result += sum(v1) + sum(v2) + sum(v3) + sum(v7) + sum(v9);
        }
        else {
            result += sum(v4) + sum(v5) + sum(v6) + sum(v8) + sum(v10);
        }
    }
    return result;
}
int func(int value, int* pointer) {
    auto lambda1 = [](int arg)  {
        for (int i = 0; i < 5; i++) {
            if (arg <= 100) {
                g_v += arg + i;
            }
        }
        return 7878;
    };
    auto lambda2 = [](int* argp) {
        for (int i = 0; i < 10; i++) {
            if (i != 2) {
                g_v += *argp + i;
            }
        }
        return 8787;
    };
    int a = sum(1) + value;
    int b = sum(1) + *pointer;
    if (value != -1 && pointer != nullptr) {
        for (int i = 0; i < value + *pointer; i++) {
            a += b + i;
            a += i * 2;
            b += 3;
            int c = 0;
            ReadProcessMemory((HANDLE)-1, &a, &c, sizeof(int), nullptr);
            LPVOID buffer = VirtualAlloc(NULL, 4096, MEM_COMMIT, PAGE_READWRITE);
            *(uint32_t*)buffer = stack_test(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) + c;
            g_v += *(uint32_t*)buffer;
            for (int j = 0; j < 10; j++) {
                if (j == 2 || i == 3) {
                    for (int k = 0; k < 3; k++) {
                        g_v -= j + k * c;
                        if (g_v > 10) {
                            g_v--;
                        }
                    }
                }
                else {
                    g_v += *(uint32_t*)buffer * 2 + c;
                }
            }
        }
        g_v += lambda1(a);
        g_v += lambda2(&b);
        for (int i = 0; i < value + 5; i++) {
            for (int j = 0; j < 6; j++) {
                if (j == 3) {
                    for (int k = 0; k < 3; k++) {
                        g_v += j + k * j;
                        if (g_v > 10) {
                            g_v--;
                        }
                    }
                }
                else {
                    if (j == 4) {
                        g_v ^= 0x1000;
                    }
                    *(uint8_t*)(&b) ^= 0x10;
                    a -= b;
                }
            }
            a += b;
        }
        for (int j = 0; j < 10; j++) {
            if (j == 2) {
                for (int k = 0; k < 3; k++) {
                    g_v += j + k * 10;

                }
            }
            if (g_v > 1000) {
                return value + g_v;
            }
            else {
                if (g_v > 100) {
                    g_v += j + 10;
                }
            }
        }
    }
    return value + a + b + g_v;
}

#ifdef __cplusplus
extern "C" {
#endif
    int MasmFunc(int value, int* pointer);
    uintptr_t qword_14001C7E8 = (uintptr_t)ReadProcessMemory;
    uintptr_t qword_14001C868 = (uintptr_t)VirtualAlloc;
    uintptr_t sub_140001170 = (uintptr_t)stack_test;
#ifdef __cplusplus
}
#endif

int main() {
    for (int i = 0; i < 100; i++) {
        int result1 = MasmFunc(i, &i);
        int result2 = func(i, &i);
        printf("%8d   %8d\n", result1, result2);
        if (result1 != result2) {
            DebugBreak();
        }
    }
    return 0;
}
﻿#include<Windows.h>
#include<stdio.h>
#include<stdint.h>
#include<stdlib.h>

int g_v = 0;

int __attribute((__annotate__(("fla,sub,split,bcf")))) sum(int n) {
    if (n == 0) {
        return 0;
    }
    return 1 + sum(n - 1);
}

int __stdcall stack_test(int v1, int v2, int v3, int v4, int v5, int v6, int v7, int v8, int v9, int v10) {
    int result = 0;
    for (size_t i = 0; i < sum(2); i++) {
        if (i == 0) {
            result += sum(v1) + sum(v2) + sum(v3) + sum(v7) + sum(v9);
        }
        else {
            result += sum(v4) + sum(v5) + sum(v6) + sum(v8) + sum(v10);
        }
    }
    return result;
}

int __attribute((__annotate__(("fla,sub,split,bcf")))) func(int value, int* pointer) {
    int a = sum(1) + value;
    int b = sum(1) + *pointer;
    if (value != -1 && pointer != nullptr) {
        for (int i = 0; i < value + *pointer; i++) {
            a += b + i;
            a += i * 2;
            b += 3;
            int c = 0;
            ReadProcessMemory((HANDLE)-1, &a, &c, sizeof(int), nullptr);
            LPVOID buffer = VirtualAlloc(NULL, 4096, MEM_COMMIT, PAGE_READWRITE);
            *(uint32_t*)buffer = stack_test(1, 2, 3, 4, 5, 6, 7, 8, 9, 10) + c;
            g_v += *(uint32_t*)buffer;
        }
    }
    return value + a + b + g_v;
}

int main() {
    int value = 10;
    int pointer = 20;
    printf("%d\n", func(value, &pointer));
    return 0;
}